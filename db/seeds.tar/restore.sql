--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.articles DROP CONSTRAINT fk_rails_3d31dad1cc;
ALTER TABLE ONLY public.comments DROP CONSTRAINT fk_rails_3bf61a60d3;
ALTER TABLE ONLY public.comments DROP CONSTRAINT fk_rails_03de2dc08c;
DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_users_on_reset_password_token;
DROP INDEX public.index_users_on_email;
DROP INDEX public.index_comments_on_user_id;
DROP INDEX public.index_comments_on_article_id;
DROP INDEX public.index_articles_on_user_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.comments DROP CONSTRAINT comments_pkey;
ALTER TABLE ONLY public.articles DROP CONSTRAINT articles_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.articles ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.comments_id_seq;
DROP TABLE public.comments;
DROP SEQUENCE public.articles_id_seq;
DROP TABLE public.articles;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: socialnet_dev
--

CREATE TABLE articles (
    id integer NOT NULL,
    title character varying,
    text text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer,
    published boolean DEFAULT false NOT NULL,
    published_at timestamp without time zone
);


ALTER TABLE articles OWNER TO socialnet_dev;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: socialnet_dev
--

CREATE SEQUENCE articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE articles_id_seq OWNER TO socialnet_dev;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: socialnet_dev
--

ALTER SEQUENCE articles_id_seq OWNED BY articles.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: socialnet_dev
--

CREATE TABLE comments (
    id integer NOT NULL,
    body text,
    article_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer
);


ALTER TABLE comments OWNER TO socialnet_dev;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: socialnet_dev
--

CREATE SEQUENCE comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE comments_id_seq OWNER TO socialnet_dev;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: socialnet_dev
--

ALTER SEQUENCE comments_id_seq OWNED BY comments.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: socialnet_dev
--

CREATE TABLE schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE schema_migrations OWNER TO socialnet_dev;

--
-- Name: users; Type: TABLE; Schema: public; Owner: socialnet_dev
--

CREATE TABLE users (
    id integer NOT NULL,
    name character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip inet,
    last_sign_in_ip inet,
    role character varying DEFAULT 'user'::character varying NOT NULL
);


ALTER TABLE users OWNER TO socialnet_dev;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: socialnet_dev
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO socialnet_dev;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: socialnet_dev
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY articles ALTER COLUMN id SET DEFAULT nextval('articles_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY comments ALTER COLUMN id SET DEFAULT nextval('comments_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: socialnet_dev
--

COPY articles (id, title, text, created_at, updated_at, user_id, published, published_at) FROM stdin;
\.
COPY articles (id, title, text, created_at, updated_at, user_id, published, published_at) FROM '$$PATH$$/2200.dat';

--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: socialnet_dev
--

SELECT pg_catalog.setval('articles_id_seq', 7, true);


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: socialnet_dev
--

COPY comments (id, body, article_id, created_at, updated_at, user_id) FROM stdin;
\.
COPY comments (id, body, article_id, created_at, updated_at, user_id) FROM '$$PATH$$/2202.dat';

--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: socialnet_dev
--

SELECT pg_catalog.setval('comments_id_seq', 1, false);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: socialnet_dev
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2205.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: socialnet_dev
--

COPY users (id, name, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, role) FROM stdin;
\.
COPY users (id, name, created_at, updated_at, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, role) FROM '$$PATH$$/2204.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: socialnet_dev
--

SELECT pg_catalog.setval('users_id_seq', 4, true);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_articles_on_user_id; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE INDEX index_articles_on_user_id ON articles USING btree (user_id);


--
-- Name: index_comments_on_article_id; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE INDEX index_comments_on_article_id ON comments USING btree (article_id);


--
-- Name: index_comments_on_user_id; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE INDEX index_comments_on_user_id ON comments USING btree (user_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: socialnet_dev
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: comments fk_rails_03de2dc08c; Type: FK CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT fk_rails_03de2dc08c FOREIGN KEY (user_id) REFERENCES users(id);


--
-- Name: comments fk_rails_3bf61a60d3; Type: FK CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT fk_rails_3bf61a60d3 FOREIGN KEY (article_id) REFERENCES articles(id);


--
-- Name: articles fk_rails_3d31dad1cc; Type: FK CONSTRAINT; Schema: public; Owner: socialnet_dev
--

ALTER TABLE ONLY articles
    ADD CONSTRAINT fk_rails_3d31dad1cc FOREIGN KEY (user_id) REFERENCES users(id);


--
-- PostgreSQL database dump complete
--

